@echo off
cd /d "%~dp0"
call "%~dp0launcher.bat"
