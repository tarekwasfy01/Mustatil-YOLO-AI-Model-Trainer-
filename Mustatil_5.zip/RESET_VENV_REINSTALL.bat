@echo off
setlocal
cd /d "%~dp0"
echo Removing old venv and dependency markers...
if exist ".venv" rmdir /s /q ".venv"
del /q ".deps_ok_py312_v*.txt" 2>nul
del /q "launcher_install_log.txt" 2>nul
echo Done. Starting launcher fresh...
call "%~dp0launcher.bat"
